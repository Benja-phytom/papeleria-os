public class VentaPapeleria {
    private String usuario = "Benjamin";
    private double totalVenta;

    public boolean autenticar(String user, String pass) {
        return this.usuario.equals(user) && "040726".equals(pass);
    }

    public double calcularCambio(double efectivoRecibido, double total) {
        if (efectivoRecibido >= total) {
            return efectivoRecibido - total;
        } else {
            throw new IllegalArgumentException("Efectivo insuficiente");
        }
    }

    public void enviarASpoolerImpresion() {
        System.out.println("SO: Enviando datos a la impresora multifuncional...");
    }
}